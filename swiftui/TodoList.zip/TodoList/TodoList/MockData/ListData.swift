//
//  ListData.swift
//  TodoList
//
//  Created by 夏凌晨 on 2022/5/20.
//

import SwiftUI

let ListData: [ListModel] = [
  ListModel(
    text: "Swift App",
    completed: true
  ),
  ListModel(
    text: "Flutter App",
    completed: false
  ),
  ListModel(
    text: "React Native App",
    completed: false
  ),
  ListModel(
    text: "Taro Mini App",
    completed: true
  ),
];
